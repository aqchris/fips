"""These filters originated in xml_split.py to split out Nessus XML
files. They are generalized into this module.
"""

import os
import csv
import logging


class AuthenticationPluginFilter:
    log = logging.getLogger('AuthenticationPluginFilter')
    tag_type = 'ReportItem'
    plugin_whitelist = {
        '21745': 'Authentication Failure: Local Checks Not Run',
        '104410': 'Authentication Failure(s) for Provided Crednentials',
        '110095': 'Authentication Success',
        '110695': 'Authentication Success - Local Checks Not Available',
        '110385': 'Authentication Success Insufficient Access',
        '91822': 'Database Authentication Failure(s) for Provided Credentials',
        '19506': 'Nessus Scan Information',
        '110723': 'No Credentials Provided',
        '46180': 'Additional DNS Hostnames',
        '39520': 'Backported Security Patch Detection',
        '55472': 'Device Hostname',
        '12053': 'Host Fully Qualified Domain Name'
    }

    def __init__(self, param):
        pass

    def test(self, node):
        if node.tag == 'ReportItem' and node.attrib['pluginID'] in self.plugin_whitelist:
            return True
        return False


class ReportHostBlacklist:
    log = logging.getLogger('ReportHostBlacklist')
    tag_type = 'ReportHost'

    def __init__(self, csv_filename):
        self.csv_filename = csv_filename
        self.initialized = False
        self.data = {}

    def initialize(self):
        if os.path.exists(self.csv_filename):
            self.log.debug('ReportHostBlacklist parameter file exists to initialize: {}'.format(self.csv_filename))
            with open(self.csv_filename) as csvfp:
                reader = csv.DictReader(csvfp, fieldnames=['hostname', 'ip'])
                for row in reader:
                    if row['hostname']:
                        self.data[row['hostname']] = True
                    if row['ip']:
                        self.data[row['ip']] = True
            self.initialized = True
            self.log.debug('ReportHostBlacklist initialized with {} data points'.format(len(self.data)))
        else:
            raise ValueError('The filename passed in {} does not appear to exist'.format(self.csv_filename))

    def test(self, node):
        """Return True/False based on filter.
        """
        if not self.initialized:
            self.initialize()

        # if the name of the host matches ip or hostname, return false
        if node.tag == 'ReportHost' and 'name' in node.attrib and node.attrib['name'] in self.data:
            return False
        return True


class RiskFactorFilter:
    log = logging.getLogger('RiskFactorFilter')
    tag_type = 'ReportItem'

    def __init__(self, risk_factor_list):
        self.risk_list = list(map(lambda x: x.lower(), risk_factor_list.split(',')))
        self.log.debug('Initialized with risk_factor_list {}'.format(self.risk_list))

    def __str__(self):
        return '<RiskFactorFilter {}>'.format(self.risk_list)

    def test(self, node):
        if node.tag == 'ReportItem':
            risk_factor = node.find('./risk_factor')
            if risk_factor is not None:
                raw_level = risk_factor.text.lower()
                if raw_level in self.risk_list:
                    self.log.debug('Match {} to {}'.format(raw_level, self.risk_list))
                    return True
            else:
                self.log.debug('No <risk_factor> tag found for <ReportItem>')
        return False


class SeverityFilter:
    log = logging.getLogger('SeverityFilter')
    tag_type = 'ReportItem'

    def __init__(self, include_exclude):
        if include_exclude == 'exclude':
            self.remove = True
        else:
            self.remove = False
        self.log.info('Filter set to remove {}'.format(self.remove))

    def test(self, node):
        if node.tag == 'ReportItem' and 'severity' in node.attrib and node.attrib['severity'] == '0':
            if self.remove:
                return True
            else:
                return False
        return True
