import os
import boto3
import botocore
import logging
import sys
from datetime import date, timedelta
from securitycenter import SecurityCenter5

logging.basicConfig(format='%(asctime)-15s | %(levelname)s | %(filename)s:%(lineno)d | %(name)s.%(funcName)s | %(message)s')


class S3:
    """S3 Connector to put .nessus files.
    """
    log = logging.getLogger('S3')

    def __init__(self, kms_key_id, s3_bucket):
        self.kms_key_id = kms_key_id
        self.s3_bucket = s3_bucket

        # boto3 clients
        self.s3 = None
        self.kms = None

    def check_file_size(self, s3_key, sizeof):
        """Get metadata of s3 object and see if we already uploaded it with matching size.

        Returns True if size matches the target key.
        """
        try:
            obj = self.s3.head_object(Bucket=self.s3_bucket, Key=s3_key)
        except botocore.exceptions.ClientError as e:
            exception = sys.exc_info()
            code = int(e.response['Error']['Code'])
            if code == 404:
                self.log.info('s3://{}/{} does not exist, assuming new object to upload.'.format(self.s3_bucket,
                                                                                                 s3_key))
                return False
            else:
                self.log.error('Received code {}, which is unexpected. Rethrowing'.format(code))
                raise exception[0], exception[1], exception[2]

        if obj['ContentLength'] == sizeof:
            self.log.info('s3://{}/{} matches passed in size of {}'.format(self.s3_bucket,
                                                                           s3_key,
                                                                           sizeof))
            return True

        self.log.info('Content Length for s3://{}/{}'.format(self.s3_bucket,
                                                             s3_key,
                                                             sizeof))
        return False

    def connect(self):
        s3 = boto3.client('s3')
        kms = boto3.client('kms')

        # test for bucket existence
        try:
            s3.head_bucket(Bucket=self.s3_bucket)
            self.s3 = s3
            self.log.info('Found expected S3 bucket: {}'.format(self.s3_bucket))
        except botocore.exceptions.ClientError as e:
            code = int(e.response['Error']['Code'])
            if code == 403:
                self.log.error('403 Error, Bucket {} likely does not exist.'.format(self.s3_bucket))
            else:
                self.log.error('Unexpected error code {}: {}'.format(code, str(e.response)))
            return False

        # find KMS key by tag. There does not seem to be a better way
        # aside from just iterating after performing a list operation.
        key = kms.describe_key(KeyId=self.kms_key_id)
        self.log.info('Found KMS KeyId {} with Description {}'.format(self.kms_key_id, key['KeyMetadata']['Description']))
        self.kms = kms
        return True

    def key_exists(self, s3_key):
        try:
            self.s3.head_object(Bucket=self.s3_bucket, Key=s3_key)
            return True
        except botocore.exceptions.ClientError as e:
            exception = sys.exc_info()
            code = int(e.response['Error']['Code'])
            if code == 404:
                self.log.info('s3://{}/{} does not exist, assuming new object to upload.'.format(self.s3_bucket,
                                                                                                 s3_key))
                return False
            else:
                self.log.error('Received code {}, which is unexpected. Rethrowing'.format(code))
                raise exception[0], exception[1], exception[2]

    def put_file(self, file_name, s3_key):
        if not self.s3 or not self.kms:
            self.log.error('s3 or kms not initialized, call connect() first')
            return False

        with open(file_name, 'rb') as data:
            self.s3.upload_fileobj(data, self.s3_bucket, s3_key,
                                   ExtraArgs={'ServerSideEncryption': 'aws:kms',
                                              'SSEKMSKeyId': self.kms_key_id})
        self.log.info('Uploaded {} as {}'.format(file_name, s3_key))
        return True


class SecurityCenter:
    """SecurityCenter Connector to get .nessus files and delete scan
    results.
    """
    log = logging.getLogger('SecurityCenter')

    def __init__(self):
        self.envmap = {}
        self.sc = None
        self.connected = False

    def check_env(self):
        required_env = [
            'SECURITYCENTER_LOGIN',
            'SECURITYCENTER_PASSWORD',
            'SECURITYCENTER_HOST'
        ]
        optional_env = [
            'SECURITYCENTER_PORT'
        ]

        # Required Variables
        for v in required_env:
            if v in os.environ:
                self.envmap[v] = os.environ[v]
                self.log.debug('Extracted value from envvar {} into local map.'.format(v))
            else:
                self.log.error('Required environment variable {} was not set.'.format(v))
                return False

        # Optional Variables
        for v in optional_env:
            if v in os.environ:
                self.envmap[v] = os.environ[v]
                self.log.debug('Extracted optional value from envvar {} into local map.'.format(v))
            else:
                self.log.debug('Optional environment variable {} was not set.'.format(v))

        return True

    def connect(self):
        if not self.check_env():
            self.log.error("Failed to check_env during a connect()")
            return False

        self.sc = SecurityCenter5(self.envmap['SECURITYCENTER_HOST'],
                                  self.envmap['SECURITYCENTER_PORT'])

        self.sc.login(self.envmap['SECURITYCENTER_LOGIN'],
                      self.envmap['SECURITYCENTER_PASSWORD'])

        self.connected = True
        self.log.debug('Logged in to SecurityCenter on {}:{}'.format(self.envmap['SECURITYCENTER_HOST'],
                                                                     self.envmap['SECURITYCENTER_PORT']))

    def delete_scan(self, delete_id):
        if not self.connected:
            self.log.error('Not initialized, call .connect() first.')
            return False

        self.log.info('Deleted scan {} via DELETE scanResult/{}'.format(delete_id, delete_id))
        self.sc.delete('scanResult/{}'.format(delete_id))

        return True

    def get_scans_in_range(self, days_start, days_end=0):
        """Select scans in a range.

        This works by ordinary integer counting of days. For example
        to get scans for the last 30 days, pass days_start=30,
        days_end=0. For the last year pass days_start=365, days_end=0.

        days_start :: must be greater than days_end, and positive.

        days_end :: must be less than days_start, and can be <=
        0. Defaults to 0 so as to get all possible scans.

        Returns None on failure, json blob on success
        """
        if not self.connected:
            self.log.error('Not initialized, call .connect() first.')
            return None

        if days_start <= days_end:
            self.log.error('days_start must be greater than days_end.')
            return None
        elif days_start < 1:
            self.log.error('days_start must be greater than one, to indicate 1 day in the past.')
            return None
        elif days_end < 0:
            self.log.error('days_end must be greater than or equal to zero, as zero means now.')
            return None

        scans = self.sc.get('scanResult', params={
            'startTime': (date.today() - timedelta(days=days_start)).strftime('%s'),
            'endTime': (date.today() - timedelta(days=days_end)).strftime('%s')
        })

        if not scans.status_code == 200:
            self.log.error('Status code for the scan request was not 200, aborting code was {}.'.format(scans.status_code))
            self.log.debug('Raw response was {}'.format(scans.raw_text))
            return None

        return scans.json()

    def get_scan_details(self, scan_id):
        """Get the scan details of a particular id.

        Returns None on error, json on success.
        """

        if not self.connected:
            self.log.error('Not initialized, call .connect() first.')
            return None

        if isinstance(scan_id, (int, long)) and scan_id <= 0:
            self.log.error('The scan_id is always an integer and greater than zero.')
            return None

        self.log.info('Calling scanResult/{}'.format(scan_id))
        scan = self.sc.get('scanResult/{}'.format(scan_id))

        if not scan.status_code == 200:
            self.log.error('Status code for the scan request was not 200, aborting code was {}.'.format(scan.status_code))
            self.log.debug('Raw response was {}'.format(scan.raw_text))
            return None

        return scan.json()

    def scan_results_to_file(self, scan_id, filelike):
        result = self.sc.post('scanResult/{}/download'.format(scan_id),
                              stream=True)
        if result:
            for chunk in result.iter_content(chunk_size=16024):
                if chunk:
                    filelike.write(chunk)
            filelike.flush()
            filelike.close()
            return True
        else:
            self.log.error('Request to retrieve scan id {} failed with status code {} and reason {}'.format(scan_id,
                                                                                                            result.status_code,
                                                                                                            result.text))
            return False
