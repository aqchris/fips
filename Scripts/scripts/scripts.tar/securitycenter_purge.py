"""This is an example script to transfer data from SecurityCenter to
S3 and then later purge it.
"""

import re
import json
import logging
import os
import os.path
import sys
import archive.connector as connector
from tempfile import NamedTemporaryFile

KMS_KEYID = '9df5df43-0c24-47cd-a432-f11a43ff82ca'
S3_BUCKET = 'scanalith.scng-infrastructure-production.archive'


def transfer_scan_details(sc, s3, detail_id):
    # we receive the scan details as a json blob, which we format and
    # then stick into s3
    details = sc.get_scan_details(detail_id)

    formatted_details = json.dumps(details['response'], indent=2, sort_keys=True)

    # the regex filter removes whitespace and forward slashes which
    # are troublesome to s3 key names. The finishTime is in unix time
    # and generally should be in any datum we want to purge
    filtered_key_name = '{}-{}-{}.data.json'.format(detail_id,
                                                    re.sub(r'[\s/]', '_', details['response']['name']),
                                                    details['response']['finishTime'])
    logging.info('Uploading {} to S3'.format(filtered_key_name))

    if s3.check_file_size(filtered_key_name, len(formatted_details)):
        logging.info('Skipped re-upload of {}'.format(filtered_key_name))
        return

    tmp = NamedTemporaryFile(prefix='scandetails_', delete=False)
    name_tmp = tmp.name
    tmp.write(formatted_details)
    tmp.flush()
    tmp.close()

    s3.put_file(tmp.name, filtered_key_name)

    logging.debug('Removing temporary file {}'.format(tmp.name))
    os.remove(name_tmp)


def transfer_scan_results(sc, s3, scan):

    details = sc.get_scan_details(scan['id'])
    filtered_key_name = '{}-{}-{}.nessus'.format(scan['id'],
                                                 re.sub(r'[\s/]', '_', details['response']['name']),
                                                 details['response']['finishTime'])

    logging.info('Downloading scan id {} from SecurityCenter to upload to {}'.format(scan['id'],
                                                                                     filtered_key_name))

    if os.environ['SKIP_KNOWN'] and s3.key_exists(filtered_key_name):
        logging.info('SKIP_KNOWN for {}, not verifying transferred file size'.format(filtered_key_name))
        return True

    tmp = NamedTemporaryFile(prefix='scanresult_', delete=False)
    name_tmp = tmp.name

    if sc.scan_results_to_file(scan['id'], tmp):
        if s3.check_file_size(filtered_key_name, os.path.getsize(name_tmp)):
            logging.info('Skipped re-upload of {}'.format(filtered_key_name))
        else:
            logging.info('Uploading {} to S3'.format(filtered_key_name))
            s3.put_file(tmp.name, filtered_key_name)

        os.remove(name_tmp)
        return True
    else:
        os.remove(name_tmp)
        return False


def transfer_range(sc, s3, days_start, days_end):
    selected_scans = sc.get_scans_in_range(days_start, days_end)

    # not all scans finish
    completed_id_list = {}
    other_id_list = {}
    for scan in selected_scans['response']['usable']:
        if scan['status'] == 'Completed':
            completed_id_list[scan['id']] = scan
        else:
            other_id_list[scan['id']] = scan

    # upload details of scans we are to purge
    details_id_list = completed_id_list.keys() + other_id_list.keys()
    count = 0
    for detail_id in details_id_list:
        count += 1
        logging.info('[{}/{}] Transferring Details for ID {}'.format(count, len(details_id_list), detail_id))
        transfer_scan_details(sc, s3, detail_id)

    count = 0
    for scan in completed_id_list:
        count += 1
        logging.info('[{}/{}] Transferring Scan Results for ID {}'.format(count, len(completed_id_list), scan))
        transfer_scan_results(sc, s3, completed_id_list[scan])

    if 'CONFIRM_DELETE' in os.environ:
        logging.info('Found CONFIRM_DELETE in environment')
        delete_list = completed_id_list.keys() + other_id_list.keys()
        count = 0
        for delete_id in delete_list:
            count += 1
            logging.info('[{}/{}] Deleting scan {}'.format(count, len(delete_list), delete_id))
            sc.delete_scan(delete_id)


def main():
    logging.getLogger().setLevel(logging.INFO)
    s3 = connector.S3(KMS_KEYID, S3_BUCKET)
    sc = connector.SecurityCenter()
    s3.connect()
    sc.connect()

    transfer_range(sc, s3, 365, 90)


if __name__ == "__main__" and not sys.flags.interactive:
    main()
