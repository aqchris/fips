import os
import sys
from xml.etree.ElementTree import iterparse
from zipfile import ZipFile

class NessusExtractor:
    def __init__(self, compressed=True):
        """Create a new NessusExtractor.

        The `compressed` parameter is whether or not the file is
        gzip'd so it is easier to stream. By default Nessus via the UI
        or API spits out a compressed file that has to be unpacked.
        """
        self.compressed = compressed
        self.callbacks = []
        self.filter_results = {}

    def add_reportitem_filter(self, filter_name, fn):
        """Add a filter function to apply to the stream to extract information.

        The fn should accept an XMLElement Node. The fn should return
        a 2-tuple with the first value being True or False if it
        passed and the second value being an arbitrary value that you
        wanted to extract.

        Throws TypeError if fn is not a function.

        """
        if callable(fn):
            self.callbacks.append((filter_name, fn))
        else:
            raise TypeError('Filter added is not callable(): {}'.format(fn))

    def do(self, stream):
        """Decompress from an open file stream.
        """
        if self.compressed:
            zip = ZipFile(stream)
            if len(zip.namelist()) != 1:
                raise IOError("""The zipfile found at the stream has
                more than one file name. A SecurityCenter/Nessus export only
                should export with one file in the zip. {}""" %
                              zip.namelist())
            with zip.open(zip.namelist()[0]) as scan:
                ctx = iterparse(scan, events=('start', 'end'))
                ctx = iter(ctx)
                event, root = ctx.next()

                # The two major containing tags are the policy and the
                # report. We generally only care about the report
                # results as the policy can be exported and examined
                # separately. We should not assume order so we need to
                # advance until we find the report section.

                # NessusClientData_v2/Policy
                # NessusClientData_v2/Report

                for event, elem in ctx:
                    if event == 'start' and elem.tag == 'Report':
                        # we are in the report section
                        report_root = elem
                        for event, report_host in ctx:
                            if event == 'start' and report_host.tag == 'ReportHost':
                                host = report_host.get('name')
                                
                                # scan until we have a full ReportItem
                                # block loaded and abandon this inner
                                # loop whenever we see the end of a
                                # ReportHost.
                                for event, report_item in ctx:
                                    if event == 'end' and report_item.tag == 'ReportHost':
                                        break
                                    if event == 'end' and report_item.tag == 'ReportItem':
                                        for fn in self.callbacks:
                                            result = fn[1](report_item)
                                            if len(result) == 2 and result[0]:
                                                if host not in self.filter_results:
                                                    self.filter_results[host] = {fn[0]: [result[1]]}
                                                else:
                                                    self.filter_results[host][fn[0]].append(result[1])
                                            report_item.clear()

                    # to prevent excessive memory usage we need to
                    # clear this.
                    if event == 'end' and elem.tag =='Policy':
                        root.clear()
        else:
            raise NotImplementedError('NessusExtractor can only do compressed files.')

def ssh_authentication(node):
    if node.get('pluginName') == 'Authentication Failure(s) for Provided Credentials':
        return (True, (False, node.get('port')))
    elif node.get('pluginName') == 'Authentication Success':
        return (True, (True, node.get('port')))
    else:
        return (False, None)

if __name__ == '__main__' and not sys.flags.interactive:
    with open('/home/awfuller/Downloads/SCNG-1202.zip', 'rb') as fp:
        n = NessusExtractor()
        n.add_reportitem_filter('ssh_authentication', ssh_authentication)
        n.do(fp)
        for host in n.filter_results:
            if 'ssh_authentication' in n.filter_results[host]:
                print '{} | {}'.format(host, ', '.join(map(lambda x: '+'+x[1] if x[0] else '-'+x[1], n.filter_results[host]['ssh_authentication'])))
        
