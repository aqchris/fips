"""This splits a particular scan into a sequence of hashed files to
make it easier to generate JIRA tickets by hand.
"""
import re
import os
import sys
import json
import logging
from argparse import ArgumentParser
from filters.nessus import RiskFactorFilter
from hashlib import sha256
from jira import JIRA
from pprint import PrettyPrinter
from xml.etree.cElementTree import iterparse
from zipfile import ZipFile, is_zipfile

logging.basicConfig(format='%(asctime)-15s | %(levelname)s | %(filename)s:%(lineno)d | %(name)s.%(funcName)s | %(message)s')


class CLI:
    log = logging.getLogger('CLI')
    usage = """xml-postprocess <command> <command_arg1> .. <command_argN> [--options]
Where command is one of the following:

xml-postprocess generate <in_file> <out_dir>
xml-postprocess ticket <jira_ticket> <in_dir>

Where options are one or more of the following:

--log-info :: set logging state to INFO
--log-debug :: set logging state to DEBUG
--dry-run :: do not ticket or generate files, print instead
--filter :: See filters section below, but only works with 'generate'
--unique-threshold :: Count of tickets required to be 'interesting enough' to post the output.
    Only works with 'ticket'

filter-name list:

    risk-factor :: comma separated parameter of critical,high,medium,low
"""
    filter_map = {'risk-factor': RiskFactorFilter}

    def __init__(self):
        self.commands = {
            'generate': self.generate,
            'ticket': self.ticket
        }
        self.dry_run = False
        self.host_filters = []
        self.item_filters = []
        self.jira_ticket = None
        self.working_file = None
        self.working_dir = None
        self.command = None
        self.unique_threshold = 1

    def do(self, argv=sys.argv):
        parser = ArgumentParser(usage=CLI.usage)
        parser.add_argument('command')
        parser.add_argument('--log-debug', action='store_true')
        parser.add_argument('--log-info', action='store_true')
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument('--filter', nargs=2, action='append')
        parser.add_argument('--unique-threshold', nargs=1, type=int)

        filtered_argv = argv[1:]
        # extract filters. The goal is to extract --filter arg1 arg2
        filters = []
        filter_counter = 0
        unique_threshold = []
        unique_threshould_counter = 0
        passthru_argv = []
        for arg in argv:
            if arg == '--filter':
                filter_counter = 1
                filters.append(arg)
            elif filter_counter == 1:
                filter_counter = 2
                filters.append(arg)
            elif filter_counter == 2:
                filters.append(arg)
                filter_counter = 0
            elif arg == '--unique-threshold':
                unique_threshould_counter = 1
                unique_threshold.append(arg)
            elif unique_threshould_counter == 1:
                unique_threshould_counter = 0
                unique_threshold.append(arg)
            else:
                passthru_argv.append(arg)

        filtered_argv = filtered_argv[:1] + list(filter(lambda x: re.match(r'^--(?!filter|unique-threshold)', x), filtered_argv)) + filters + unique_threshold
        passthru_argv = list(filter(lambda x: not re.match(r'^--', x), passthru_argv[2:]))
        args = parser.parse_args(filtered_argv)

        if args.log_info:
            self.log.setLevel(logging.INFO)
            self.log.info('Setting log level of INFO')

        if args.log_debug:
            self.log.setLevel(logging.DEBUG)
            self.log.debug('Setting log level of DEBUG')

        if args.dry_run:
            self.dry_run = True
            self.log.info('--dry-run mode set to True')

        if args.filter:
            for f in args.filter:
                if f[0] in self.filter_map:
                    cls = self.filter_map[f[0]](f[1])
                    if hasattr(cls, 'tag_type') and cls.tag_type == 'ReportHost':
                        self.log.debug('Added host filter {} with parameter {}'.format(f[0], f[1]))
                        self.host_filters.append(cls)
                    elif hasattr(cls, 'tag_type') and cls.tag_type == 'ReportItem':
                        self.log.debug('Added item filter {} with parameter {}'.format(f[0], f[1]))
                        self.item_filters.append(cls)
                    else:
                        self.log.error('Filter {} has missing or unknown tag type to filter against.'.format(f[0]))
                else:
                    self.log.error('Unknown filter {}'.format(f[0]))

        if args.unique_threshold:
            self.unique_threshold = args.unique_threshold[0]

        if args.command and args.command in self.commands:
            self.command = args.command
            self.log.info("Selected command '{}'".format(self.command))
        else:
            self.log.error("Command '{}' is not a known command. Known commands are {}".format(args.command,
                                                                                               self.commands.keys()))
            return False

        return self.commands[self.command](passthru_argv)

    def generate(self, argv):
        self.log.debug('Entered command generate with argv {}'.format(argv))
        parser = ArgumentParser(usage=CLI.usage)
        parser.add_argument('in_file')
        parser.add_argument('out_dir')
        args = parser.parse_args(argv)

        if not os.path.exists(args.in_file):
            self.log.error('The designated in_file was not found: {}'.format(args.in_file))
            return False
        else:
            self.log.info('Designated in_file was found: {}'.format(args.in_file))
            self.working_file = args.in_file

        if not os.path.isdir(args.out_dir):
            self.log.error('The designated out_dir was not found (or was not a directory): {}'.format(args.out_dir))
            return False
        else:
            self.log.info('Designated out_dir was found: {}'.format(args.out_dir))
            self.working_dir = args.out_dir

        self.open_file_stream()

        return False

    def open_file_stream(self):
        fp = None
        xml_fp = None
        if is_zipfile(self.working_file):
            self.log.info('The in_file was a ZipFile')
            xml_fp = open(self.working_file, 'rb')
            zip_xml = ZipFile(xml_fp)
            self.log.debug('Namelist of the download XML file was {}'.format(zip_xml.namelist()))
            fp = zip_xml.open(zip_xml.namelist()[0])
        else:
            self.log.info('The in_file was not a ZipFile')
            fp = open(self.working_file)

        self.make_tickets(fp)

        if xml_fp:
            xml_fp.close()
        if fp:
            fp.close()

        return True

    def make_tickets(self, fp):
        """Generate tickets one per file as JSON objects.

        --log-info should provide information about the host level,
        while --log-debug should provide information at the item
        level.
        """
        # The ticket map is something that uses the same counting as
        # is generally done. There is one plugin name with one or many
        # outputs that provide useful information. We will have to try
        # and accumulate these outputs as we go along in the stream.

        # Because this is designed for the full fleet scans it is not
        # going to be trying to identify individual machines like some
        # of the processing done for Pipelines.

        # The format is sha256 hash of the plugin name as first level key
        ticket_map = {}

        if fp.closed:
            self.log.error('fp was closed')

        # open XML stream
        xml = iterparse(fp, events=('start', 'end'))
        ctx = iter(xml)
        _, root = ctx.next()

        # hold references to critical nodes and logging counters
        report_root = None
        report_host_count = 0
        filtered_host_count = 0

        for event, elem in ctx:
            # Flush unneeded header from memory
            if event == 'end' and elem.tag == 'Policy':
                root.clear()

            # Since the 'Report' tag is consistent across all the
            # split scans it is important to keep this data
            if event == 'start' and elem.tag == 'Report':
                report_root = elem

            if event == 'end' and elem.tag == 'ReportHost':
                # skip = False
                report_host_count += 1
                if report_host_count % 10 == 0:
                    self.log.info('{}th <ReportHost>, {} hosts removed by filter'.format(report_host_count, filtered_host_count))

                # Host filters should be added here and set skip to True, then do a loop control continue

                # item filters should be added here
                removed_items = 0
                remove_list = []

                for item in elem.iterfind('./ReportItem'):
                    for f in self.item_filters:
                        if not f.test(item):
                            removed_items += 1
                            self.log.debug('Marked for Removal <ReportHost>/<ReportItem> {}/{} based on filter {}'.format(elem.attrib['name'],
                                                                                                                          item.attrib['pluginName'],
                                                                                                                          f))
                            remove_list.append(item)
                            break  # stop at first failure

                for item in remove_list:
                    elem.remove(item)

                # reselect subtree after filters
                items = elem.findall('./ReportItem')
                for item in items:
                    datum = sha256(item.attrib['pluginName']).hexdigest()
                    if datum not in ticket_map:
                        ticket_map[datum] = {
                            'pluginName': item.attrib['pluginName'],
                            'severity': item.attrib['severity'],
                            'description': item.find('./description').text,
                            'outputs': {}
                        }
                        self.log.debug('Added Plugin {} to ticket_map with hash {}'.format(item.attrib['pluginName'], datum))

                    out_text = ''.join(map(lambda x: x.text, item.findall('./plugin_output')))
                    out_hash = sha256(out_text).hexdigest()
                    if out_hash not in ticket_map[datum]['outputs']:
                        ticket_map[datum]['outputs'][out_hash] = {
                            'text': out_text,
                            'count': 1
                        }
                    else:
                        ticket_map[datum]['outputs'][out_hash]['count'] += 1

                report_root.clear()

        return self.write_tickets(ticket_map)

    def submit_tickets(self, ticket_files):
        severity_map = {
            '1': 'Low',
            '2': 'Medium',
            '3': 'High',
            '4': 'Critical'
        }

        if self.dry_run:
            for ticket_file in ticket_files:
                with open(os.path.join(self.working_dir, ticket_file)) as t_raw:
                    threshold_count = 0
                    threshold_output = None
                    ticket_data = json.loads(t_raw.read())
                    print('----- BEGIN TICKET -----')
                    print(ticket_data['pluginName'])
                    sev = severity_map[ticket_data['severity']]
                    print(sev)
                    print('h2. Description\n{}'.format(ticket_data['description']))
                    for output in ticket_data['outputs']:
                        if ticket_data['outputs'][output]['count'] < self.unique_threshold:
                            threshold_count += ticket_data['outputs'][output]['count']
                            if not threshold_output:
                                threshold_output = ticket_data['outputs'][output]['text']
                        else:
                            print('h2. {} Hosts with the following output:\n{{noformat}}{}{{noformat}}\n'.format(ticket_data['outputs'][output]['count'],
                                                                                                                 ticket_data['outputs'][output]['text']))
                    if threshold_count > 0:
                        print('h2. Unique Outputs\nThere were {} hosts that had a unique plugin output below the threshold of {}. Below is a sample output\n'.format(threshold_count,
                                                                                                                                                                     self.unique_threshold))
                        print('{{noformat}}{}{{noformat}}'.format(threshold_output))
                    print('----- END TICKET -----')
            return True

        jira_user = 'security.bot'
        jira_host = 'https://backlog.acquia.com'
        jira_pw = os.environ['SECURITYBOT_PASSWORD']
        jira = JIRA(jira_host, auth=(jira_user, jira_pw))

        parent_ticket = jira.issue(self.jira_ticket)
        subtask_list = []
        self.log.info('Was able to connect to JIRA and confirm ticket {} existed'.format(parent_ticket.key))
        for ticket_file in ticket_files:
            filename = os.path.join(self.working_dir, ticket_file)
            with open(filename) as t_raw:
                threshold_count = 0
                threshold_output = None
                ticket_data = json.loads(t_raw.read())

                jira_subtask = {
                    'project': {'key': 'SCNG'},
                    'summary': ticket_data['pluginName'],
                    'priority': {'name': severity_map[ticket_data['severity']]},
                    'labels': ['[SCNG]:Compliance', 'xml-postprocess'],
                    'components': [{'name': 'Nessus'}],
                    'issuetype': {'name': 'Sub-task'},
                    'parent': {'id': parent_ticket.id}
                }

                description = 'h2. Description\n{}\n'.format(ticket_data['description'])
                for output in ticket_data['outputs']:
                    if ticket_data['outputs'][output]['count'] < self.unique_threshold:
                        threshold_count += ticket_data['outputs'][output]['count']
                        if not threshold_output:
                            threshold_output = ticket_data['outputs'][output]['text']
                    else:
                        description += 'h2. {} Hosts with the following output:\n{{noformat}}{}{{noformat}}\n'.format(ticket_data['outputs'][output]['count'],
                                                                                                                      ticket_data['outputs'][output]['text'])
                    if threshold_count > 0:
                        description += 'h2. Unique Outputs\nThere were {} hosts that had a unique plugin output below the threshold of {}. Below is a sample output\n'.format(threshold_count,
                                                                                                                                                                              self.unique_threshold)
                        description += '{{noformat}}{}{{noformat}}\n'.format(threshold_output)

                jira_subtask['description'] = description
                if len(description) > 65000:
                    self.log.error('Ticket data in {} exceeded 65000 characters in description (real limit 65535). It was OMITTED from the JIRA ticket generation list.'.format(filename))
                else:
                    subtask_list.append(jira_subtask)

                self.log.debug(jira_subtask)

        # add a way to bail if you goofed
        print('There are {} subtasks waiting to be added to {}'.format(len(subtask_list), self.jira_ticket))
        proceed = raw_input('Proceed? (y/N): ')
        if proceed == 'y':
            count = 0
            for subtask in subtask_list:
                count += 1
                jira_ticket = jira.create_issue(fields=subtask)
                print('[{}/{}] Created ticket {}.'.format(count, len(subtask_list), jira_ticket.key))
        return True

    def ticket(self, argv):
        self.log.debug('Entered command ticket with argv {}'.format(argv))
        self.log.info('Unique Threshold is set to {}'.format(self.unique_threshold))

        parser = ArgumentParser(usage=CLI.usage)
        parser.add_argument('jira_ticket')
        parser.add_argument('in_dir')
        args = parser.parse_args(argv)

        if args.jira_ticket:
            self.log.info('Selected parent ticket for subtasks {}'.format(self.jira_ticket))
            self.jira_ticket = args.jira_ticket

        if not os.path.isdir(args.in_dir):
            self.log.error('The designated out_dir was not found (or was not a directory): {}'.format(args.in_dir))
            return False
        else:
            self.log.info('Designated out_dir was found: {}'.format(args.in_dir))
            self.working_dir = args.in_dir

        ticket_files = os.listdir(self.working_dir)
        if not ticket_files:
            self.log.error('There are no files to look for tickets in {}'.format(self.working_dir))
            return False
        else:
            self.log.info('Working with {} ticket files'.format(len(ticket_files)))

        return self.submit_tickets(ticket_files)

    def write_tickets(self, ticket_map):
        if self.dry_run:
            pp = PrettyPrinter(indent=2)
            pp.pprint(ticket_map)
            return True

        if os.listdir(self.working_dir):
            self.log.error('Files exist in target directory {}, aborting.'.format(self.working_dir))
            return False

        # We sort the tickets for mostly consistent ordering between runs
        key_counter = 0
        key_list = ticket_map.keys()
        key_list.sort()

        self.log.info('Writing {} tickets into {}'.format(len(key_list), self.working_dir))
        for key in key_list:
            self.log.info('Ticketing key {}'.format(key))
            filename = os.path.join(self.working_dir, '{}:{}'.format(key_counter, key))
            with open(filename, 'w') as f:
                self.log.debug('Writing ticket data to filename {} for plugin {}'.format(filename, ticket_map[key]['pluginName']))
                f.write(json.dumps(ticket_map[key]))
            key_counter += 1


if __name__ == "__main__" and not sys.flags.interactive:
    cli = CLI()
    cli.do()
